#!/bin/bash
# echo "This file is executable!" 

# Скачивание файла с сайта в нужную директорию
#wget -O /home/2p1s10/business-stat/load/business-stat.csv https://data.gov.ru/sites/default/files/data-20190513t1220-structure-20190513t1220.csv

# Вызов python скрипта
baseDir='/home/2p1s10/business-stat'

source $baseDir/env/bin/activate
cd $baseDir/load
python $baseDir/load/business_stats.py
deactivate

