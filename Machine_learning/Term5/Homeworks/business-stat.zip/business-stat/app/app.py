from flask import Flask

app = Flask(__name__, static_folder="static")

@app.route('/')
def index():
    index = open("static/index.html", 'r')
    page = index.read()
    index.close()


    # Загружаем данные таблицы
    tab_file = open("static/table.html", "r")
    tab = tab_file.read()
    tab_file.close()

    page = page.replace("@@TABLE@@", tab)

    return page

app.run(debug=True, host='db-learning.ithub.ru', port=1172)
